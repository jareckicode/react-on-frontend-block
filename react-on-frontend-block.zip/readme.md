# react-on-frontend-block
This is the solution how to add react app to wordpress gutenberg block